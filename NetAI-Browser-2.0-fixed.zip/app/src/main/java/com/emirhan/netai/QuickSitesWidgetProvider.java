package com.emirhan.netai;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class QuickSitesWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        String[] labels = {"Google", "YouTube", "Hepsiburada", "GitHub"};
        String[] urls = {"https://www.google.com", "https://www.youtube.com", "https://www.hepsiburada.com", "https://github.com"};
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_sites);
            for (int i = 0; i < labels.length; i++) {
                Intent intent = new Intent(context, MainActivity.class).setAction(Intent.ACTION_VIEW).setData(android.net.Uri.parse(urls[i]));
                PendingIntent pending = PendingIntent.getActivity(context, id * 10 + i, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                int viewId = context.getResources().getIdentifier("site_" + i, "id", context.getPackageName());
                views.setOnClickPendingIntent(viewId, pending);
            }
            manager.updateAppWidget(id, views);
        }
    }
}
