# NetAI Browser 2.0

Android WebView tabanlı, AI destekli mobil tarayıcı.

## Dahil edilen özellikler

- Sekmeli tarama ve sekme yöneticisi
- Gizli sekme: cache/form geçmişi kapalı, açık sekme yedeğine ve geçmişe eklenmez
- Geri / ileri / yenile
- Adres çubuğu + seçilebilir arama motoru (Google, Bing, DuckDuckGo)
- URL algılama ve hızlı web araması
- Yer imleri ve geçmiş, 100 kayıt sınırı
- Sayfada bul
- Web sayfası paylaşımı
- Masaüstü sitesi / mobil sitesi
- JavaScript, DOM Storage, üçüncü taraf çerezleri, zoom, popup/yeni sekme desteği
- Dosya yükleme ve çoklu dosya seçimi
- Android DownloadManager ile indirme
- Web siteleri için konum izni isteme
- Android ana ekranı için 3 widget:
  - Browser arama widget'ı
  - Direkt AI widget'ı
  - Hızlı siteler widget'ı
- Sürüklenebilir AI düğmesi; konumu uygulamada saklanır
- Koyu / açık / sistem varsayılanı tema
- Gemini ve Groq API desteği
- Sağlayıcıya göre model seçimi + özel model ID alanı
- AI ile doğal dilde web işlemleri:
  - “Bana Hepsiburada'yı aç.” → doğrudan Hepsiburada
  - “YouTube'u aç.” → doğrudan YouTube
  - “Google'da Android WebView ara.” → arama sonucu
  - “Bu sayfayı özetle.” → açık sayfanın metnini AI'a göndererek özetleme
- AI tarafında `OPEN_URL:` ve `SEARCH_URL:` komutlarını kontrollü biçimde uygulama

## GitHub Actions ile APK

1. `NetAI-Browser-2.0.zip` dosyasını GitHub deposuna yükle.
2. Bu arşivdeki kaynakla birlikte `.github/workflows/build.yml` dosyasını da repo içinde tut. Ayrı olarak verilen `build.yml`, ZIP'i otomatik bulup `unzip` ile açar.
3. GitHub → Actions → **Build NetAI Browser APK** → **Run workflow**.
4. Tamamlandığında **NetAI-Browser-debug** artifact'ini indir.

Workflow JDK 17, Gradle 8.7, AGP 8.6.1 ve Android SDK 35 ile debug APK üretir.

## AI anahtarları

API anahtarları kaynak koda gömülmez. Ayarlar → AI bölümünden cihaz üzerinde girilir. Uygulama bunları kendi SharedPreferences verisinde saklar.

### Gemini
Gemini REST `generateContent` çağrısı kullanılır.

### Groq
Groq'un OpenAI uyumlu Chat Completions endpoint'i kullanılır.

Not: Bir sitenin gerçekten “normal tarayıcı” olarak çalışması, sitenin WebView uyumluluğuna bağlıdır. DRM tabanlı bazı içerikler, bazı tarayıcı eklentileri ve Chrome'a özel özellikler Android WebView'ın kapsamı dışındadır.
