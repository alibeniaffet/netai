package com.emirhan.netai;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.PendingIntent;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_FILE = 4201;
    private static final int REQ_PERMISSIONS = 4202;

    private LinearLayout root, toolbar, bottomBar, homePanel;
    private FrameLayout browserFrame;
    private EditText address;
    private TextView tabCount;
    private Button backBtn, forwardBtn, reloadBtn;
    private ImageButton aiFab;
    private SharedPreferences prefs;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int currentTab = 0;
    private String theme = "system";
    private boolean desktop = false;
    private boolean restoring = false;
    private ValueCallback<Uri[]> fileCallback;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    static final class Tab {
        final WebView web;
        final boolean incognito;
        String title = "Yeni sekme";
        Tab(WebView web, boolean incognito) { this.web = web; this.incognito = incognito; }
    }

    @Override protected void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("netai_browser", MODE_PRIVATE);
        theme = prefs.getString("theme", "system");
        desktop = prefs.getBoolean("desktop", false);
        applyTheme();
        buildUi();
        restoreTabsOrCreate();

        Intent intent = getIntent();
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            final String u = intent.getData().toString();
            new Handler(Looper.getMainLooper()).postDelayed(() -> navigate(u), 150);
        } else if ("search".equals(intent.getStringExtra("widget_action"))) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> address.requestFocus(), 180);
            showHome();
            openKeyboard();
        } else if (intent.getBooleanExtra("open_ai", false)) {
            new Handler(Looper.getMainLooper()).postDelayed(this::showAiPanel, 180);
        }
    }

    private void applyTheme() {
        boolean dark = isDarkTheme();
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private boolean isDarkTheme() {
        if ("dark".equals(theme)) return true;
        if ("light".equals(theme)) return false;
        int mask = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mask == Configuration.UI_MODE_NIGHT_YES;
    }

    private int bg() { return isDarkTheme() ? Color.rgb(14, 15, 18) : Color.rgb(246, 247, 250); }
    private int panel() { return isDarkTheme() ? Color.rgb(28, 30, 35) : Color.WHITE; }
    private int card() { return isDarkTheme() ? Color.rgb(36, 39, 45) : Color.rgb(239, 241, 245); }
    private int textColor() { return isDarkTheme() ? Color.WHITE : Color.rgb(24, 26, 30); }
    private int subColor() { return isDarkTheme() ? Color.rgb(175, 181, 191) : Color.rgb(92, 98, 108); }
    private int accent() { return Color.rgb(55, 113, 235); }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView tv(String value, float sp) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(textColor());
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        return t;
    }

    private Button actionButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(18);
        b.setTextColor(textColor());
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(rounded(panel(), dp(18)));
        return b;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg());
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            WindowInsetsCompat bars = insets;
            int top = bars.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int bottom = bars.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            toolbar.setPadding(dp(8), top + dp(6), dp(8), dp(5));
            bottomBar.setPadding(dp(4), dp(3), dp(4), bottom + dp(4));
            return insets;
        });

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(62)));

        Button home = actionButton("⌂");
        toolbar.addView(home, new LinearLayout.LayoutParams(dp(44), dp(52)));
        home.setOnClickListener(v -> showHome());

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextSize(15);
        address.setTextColor(textColor());
        address.setHintTextColor(subColor());
        address.setHint("Ara veya web adresi");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setPadding(dp(16), 0, dp(10), 0);
        address.setBackground(rounded(panel(), dp(28)));
        LinearLayout.LayoutParams addressLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        addressLp.setMargins(dp(6), 0, dp(6), 0);
        toolbar.addView(address, addressLp);
        address.setOnEditorActionListener((v, actionId, event) -> {
            navigate(address.getText().toString());
            return true;
        });

        Button menu = actionButton("⋮");
        toolbar.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(52)));
        menu.setOnClickListener(v -> showMenu(v));

        browserFrame = new FrameLayout(this);
        root.addView(browserFrame, new LinearLayout.LayoutParams(-1, 0, 1f));

        aiFab = new ImageButton(this);
        aiFab.setContentDescription("AI Modu");
        aiFab.setImageResource(R.drawable.ic_ai);
        aiFab.setColorFilter(Color.WHITE);
        aiFab.setBackground(rounded(accent(), dp(32)));
        aiFab.setPadding(dp(12), dp(12), dp(12), dp(12));
        aiFab.setElevation(dp(10));
        aiFab.setOnClickListener(v -> showAiPanel());
        makeDraggable(aiFab);

        bottomBar = new LinearLayout(this);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setBackgroundColor(panel());
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, dp(62)));

        backBtn = actionButton("‹");
        forwardBtn = actionButton("›");
        reloadBtn = actionButton("↻");
        Button tabsBtn = actionButton("□");
        Button plus = actionButton("+");
        Button menuBtn = actionButton("☰");
        Button[] bs = {backBtn, forwardBtn, reloadBtn, tabsBtn, plus, menuBtn};
        for (Button b : bs) bottomBar.addView(b, new LinearLayout.LayoutParams(0, dp(54), 1f));

        backBtn.setOnClickListener(v -> { if (active() != null && active().canGoBack()) active().goBack(); });
        forwardBtn.setOnClickListener(v -> { if (active() != null && active().canGoForward()) active().goForward(); });
        reloadBtn.setOnClickListener(v -> { if (active() != null) active().reload(); });
        tabsBtn.setOnClickListener(v -> showTabs());
        plus.setOnClickListener(v -> { addTab(false); showHome(); });
        menuBtn.setOnClickListener(v -> showMenu(v));

        updateChrome();
    }

    private void restoreTabsOrCreate() {
        String saved = prefs.getString("open_tabs", "");
        if (!saved.isEmpty()) {
            try {
                JSONArray arr = new JSONArray(saved);
                restoring = true;
                int restored = 0;
                for (int i = 0; i < arr.length() && i < 8; i++) {
                    String url = arr.optString(i, "");
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        addTab(false, url, false);
                        restored++;
                    }
                }
                restoring = false;
                if (restored == 0) { addTab(false); showHome(); }
                else { switchTab(0); }
                return;
            } catch (Exception ignored) {}
        }
        addTab(false);
        showHome();
    }

    private void saveOpenTabs() {
        JSONArray arr = new JSONArray();
        for (Tab t : tabs) {
            if (!t.incognito && t.web.getUrl() != null && (t.web.getUrl().startsWith("http://") || t.web.getUrl().startsWith("https://"))) {
                arr.put(t.web.getUrl());
            }
        }
        prefs.edit().putString("open_tabs", arr.toString()).apply();
    }

    private WebView active() { return currentTab >= 0 && currentTab < tabs.size() ? tabs.get(currentTab).web : null; }

    private WebView makeWeb(final boolean incognito) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        setDesktopUA(s, desktop);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(w, true);

        if (incognito) {
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setSaveFormData(false);
            s.setDomStorageEnabled(false);
            w.clearCache(true);
            w.clearHistory();
        }

        w.setBackgroundColor(bg());
        w.setVerticalScrollBarEnabled(true);
        w.setHorizontalScrollBarEnabled(false);

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (view == active()) address.setText(url == null ? "" : url);
                super.onPageStarted(view, url, favicon);
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (view == active()) address.setText(url == null ? "" : url);
                Tab t = findTab(view);
                if (t != null) t.title = safeTitle(view.getTitle(), url);
                if (!incognito) addHistory(t == null ? url : url, t == null ? "" : t.title);
                updateChrome();
                super.onPageFinished(view, url);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) toast("Sayfa yüklenemedi");
                super.onReceivedError(view, request, error);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onReceivedTitle(WebView view, String title) {
                Tab t = findTab(view);
                if (t != null) t.title = title == null ? "Yeni sekme" : title;
                updateChrome();
            }

            @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, Message resultMsg) {
                WebView popup = makeWeb(false);
                addExistingTab(new Tab(popup, false), "about:blank");
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }

            @Override public void onCloseWindow(WebView window) {
                int index = indexOf(window);
                if (index >= 0) closeTab(index);
            }

            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accept = params.getAcceptTypes();
                String mime = "*/*";
                if (accept != null) {
                    for (String a : accept) {
                        if (a != null && !a.trim().isEmpty() && !"*/*".equals(a.trim())) { mime = a.trim(); break; }
                    }
                }
                i.setType(mime);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(i, REQ_FILE); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }

            @Override public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERMISSIONS);
                    return;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Konum izni")
                        .setMessage(origin + " konumunuza erişmek istiyor.")
                        .setPositiveButton("İzin ver", (d, which) -> callback.invoke(origin, true, false))
                        .setNegativeButton("Reddet", (d, which) -> callback.invoke(origin, false, false))
                        .show();
            }
        });

        w.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> download(url, userAgent, contentDisposition, mimeType));
        w.setOnLongClickListener(v -> false);
        return w;
    }

    private String safeTitle(String title, String url) {
        if (title != null && !title.trim().isEmpty()) return title.trim();
        if (url == null || url.trim().isEmpty()) return "Yeni sekme";
        return url;
    }

    private void addExistingTab(Tab tab, String initialUrl) {
        tabs.add(tab);
        currentTab = tabs.size() - 1;
        showBrowser();
        if (initialUrl != null && !initialUrl.isEmpty()) tab.web.loadUrl(initialUrl);
    }

    private void addTab(boolean incognito) { addTab(incognito, null, true); }

    private void addTab(boolean incognito, @Nullable String initialUrl, boolean select) {
        Tab tab = new Tab(makeWeb(incognito), incognito);
        tabs.add(tab);
        if (select) currentTab = tabs.size() - 1;
        showBrowser();
        if (initialUrl != null) tab.web.loadUrl(initialUrl);
        tab.web.requestFocus();
        address.setText(initialUrl == null ? "" : initialUrl);
    }

    private void switchTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        currentTab = index;
        showBrowser();
        String url = active() == null ? "" : active().getUrl();
        address.setText(url == null || url.startsWith("about:") ? "" : url);
        updateChrome();
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (tabs.size() == 1) {
            Tab only = tabs.get(0);
            only.web.loadUrl("about:blank");
            only.title = "Yeni sekme";
            showHome();
            return;
        }
        tabs.get(index).web.stopLoading();
        tabs.get(index).web.destroy();
        tabs.remove(index);
        if (currentTab > index) currentTab--;
        currentTab = Math.max(0, Math.min(currentTab, tabs.size() - 1));
        switchTab(currentTab);
        saveOpenTabs();
    }

    private void showBrowser() {
        if (active() == null) return;
        browserFrame.removeAllViews();
        browserFrame.addView(active(), new FrameLayout.LayoutParams(-1, -1));
        addFabToFrame();
        updateChrome();
    }

    private void showHome() {
        if (active() == null) return;
        active().loadUrl("about:blank");
        address.setText("");
        homePanel = new LinearLayout(this);
        homePanel.setOrientation(LinearLayout.VERTICAL);
        homePanel.setGravity(Gravity.CENTER_HORIZONTAL);
        homePanel.setPadding(dp(20), dp(20), dp(20), dp(20));
        homePanel.setBackgroundColor(bg());
        browserFrame.removeAllViews();
        browserFrame.addView(homePanel, new FrameLayout.LayoutParams(-1, -1));
        addFabToFrame();

        TextView title = tv("NetAI", 34);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        homePanel.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView subtitle = tv("Hızlı • Gizli • AI destekli", 14);
        subtitle.setTextColor(subColor());
        subtitle.setGravity(Gravity.CENTER);
        homePanel.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(35)));

        EditText q = new EditText(this);
        q.setSingleLine(true);
        q.setTextSize(16);
        q.setHint("Web'de ara veya adres yaz");
        q.setTextColor(textColor());
        q.setHintTextColor(subColor());
        q.setPadding(dp(18), 0, dp(18), 0);
        q.setBackground(rounded(panel(), dp(28)));
        homePanel.addView(q, new LinearLayout.LayoutParams(-1, dp(56)));
        q.setOnEditorActionListener((v, id, event) -> { navigate(q.getText().toString()); return true; });

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.setGravity(Gravity.CENTER);
        String[][] sites = {
                {"Google", "https://www.google.com"},
                {"YouTube", "https://www.youtube.com"},
                {"Hepsiburada", "https://www.hepsiburada.com"},
                {"GitHub", "https://github.com"}
        };
        for (String[] site : sites) {
            Button b = actionButton(site[0]);
            b.setTextSize(12);
            b.setPadding(dp(4), 0, dp(4), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            lp.setMargins(dp(3), dp(8), dp(3), dp(4));
            quick.addView(b, lp);
            b.setOnClickListener(v -> openUrl(site[1]));
        }
        homePanel.addView(quick, new LinearLayout.LayoutParams(-1, dp(60)));

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        ScrollView cardScroll = new ScrollView(this);
        cardScroll.setFillViewport(true);
        cardScroll.addView(cards);
        homePanel.addView(cardScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        cards.addView(homeCard("🤖", "AI Modu", "Site aç, ara, sayfayı özetle veya soru sor", v -> showAiPanel()));
        cards.addView(homeCard("▣", "Sekmeler", "Açık sekmelerini yönet", v -> showTabs()));
        cards.addView(homeCard("★", "Yer İmleri", "Kaydettiğin sayfalara ulaş", v -> showBookmarks()));
        cards.addView(homeCard("◷", "Geçmiş", "Son ziyaretlerini görüntüle", v -> showHistory()));
    }

    private View homeCard(String icon, String title, String desc, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(10), dp(4), dp(10), dp(4));
        box.setBackground(rounded(card(), dp(20)));
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(-1, dp(68));
        boxLp.setMargins(0, dp(5), 0, dp(5));
        box.setLayoutParams(boxLp);
        TextView i = tv(icon, 25);
        i.setGravity(Gravity.CENTER);
        box.addView(i, new LinearLayout.LayoutParams(dp(52), dp(58)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView a = tv(title, 17);
        a.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        TextView b = tv(desc, 12);
        b.setTextColor(subColor());
        col.addView(a, new LinearLayout.LayoutParams(-1, dp(30)));
        col.addView(b, new LinearLayout.LayoutParams(-1, dp(25)));
        box.addView(col, new LinearLayout.LayoutParams(0, -1, 1f));
        box.setOnClickListener(listener);
        return box;
    }

    private void showMenu(View anchor) {
        PopupMenu p = new PopupMenu(this, anchor);
        String[] items = {
                "Yeni sekme", "Gizli sekme", "Sekmeler", "Yer imlerine ekle", "Yer imleri", "Geçmiş",
                "Sayfada bul", "Paylaş", "Ana ekrana ekle", "Masaüstü sitesi", "Ayarlar"
        };
        for (String item : items) p.getMenu().add(item);
        p.setOnMenuItemClickListener(item -> {
            switch (item.getTitle().toString()) {
                case "Yeni sekme": addTab(false); showHome(); return true;
                case "Gizli sekme": addTab(true); showHome(); return true;
                case "Sekmeler": showTabs(); return true;
                case "Yer imlerine ekle": bookmark(); return true;
                case "Yer imleri": showBookmarks(); return true;
                case "Geçmiş": showHistory(); return true;
                case "Sayfada bul": findInPage(); return true;
                case "Paylaş": share(); return true;
                case "Ana ekrana ekle": toast("Ana ekran widget'larını uzun basılı tutarak ekleyebilirsin"); return true;
                case "Masaüstü sitesi":
                    desktop = !desktop;
                    prefs.edit().putBoolean("desktop", desktop).apply();
                    for (Tab t : tabs) setDesktopUA(t.web.getSettings(), desktop);
                    if (active() != null && active().getUrl() != null) active().reload();
                    toast(desktop ? "Masaüstü sitesi açık" : "Mobil sitesi açık");
                    return true;
                case "Ayarlar": settings(); return true;
                default: return false;
            }
        });
        p.show();
    }

    private void setDesktopUA(WebSettings s, boolean desktopMode) {
        if (desktopMode) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36");
        } else {
            s.setUserAgentString("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36");
        }
    }

    private void showTabs() {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(rounded(bg(), dp(26)));
        TextView title = tv("Sekmeler  •  " + tabs.size(), 22);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(rounded(card(), dp(18)));
            row.setPadding(dp(6), dp(4), dp(4), dp(4));
            TextView name = tv((tabs.get(i).incognito ? "🕶  " : "") + tabs.get(i).title, 14);
            Button close = actionButton("×");
            row.addView(name, new LinearLayout.LayoutParams(0, dp(54), 1f));
            row.addView(close, new LinearLayout.LayoutParams(dp(50), dp(50)));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, dp(60));
            rlp.setMargins(0, dp(3), 0, dp(3));
            rows.addView(row, rlp);
            name.setOnClickListener(v -> { switchTab(index); d.dismiss(); });
            close.setOnClickListener(v -> { closeTab(index); d.dismiss(); if (!isFinishing()) showTabs(); });
        }
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout actions = new LinearLayout(this);
        Button normal = actionButton("+ Yeni");
        Button secret = actionButton("🕶 Gizli");
        Button done = actionButton("Kapat");
        actions.addView(normal, new LinearLayout.LayoutParams(0, dp(52), 1f));
        actions.addView(secret, new LinearLayout.LayoutParams(0, dp(52), 1f));
        actions.addView(done, new LinearLayout.LayoutParams(0, dp(52), 1f));
        box.addView(actions);
        normal.setOnClickListener(v -> { addTab(false); showHome(); d.dismiss(); });
        secret.setOnClickListener(v -> { addTab(true); showHome(); d.dismiss(); });
        done.setOnClickListener(v -> d.dismiss());
        d.setContentView(box);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(24), dp(560)), Math.min(getResources().getDisplayMetrics().heightPixels - dp(80), dp(760)));
        }
    }

    private void bookmark() {
        WebView w = active();
        if (w == null || w.getUrl() == null || w.getUrl().startsWith("about:")) return;
        String title = safeTitle(w.getTitle(), w.getUrl());
        JSONArray arr = readJsonArray("bookmarks");
        for (int i = 0; i < arr.length(); i++) if (w.getUrl().equals(arr.optJSONObject(i).optString("url"))) {
            toast("Zaten yer imlerinde"); return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("title", title); o.put("url", w.getUrl());
            arr.put(0, o);
            writeJsonArray("bookmarks", arr);
            toast("Yer imlerine eklendi");
        } catch (Exception ignored) {}
    }

    private void addHistory(String url, String title) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        JSONArray arr = readJsonArray("history");
        JSONArray next = new JSONArray();
        try {
            JSONObject current = new JSONObject(); current.put("title", safeTitle(title, url)); current.put("url", url); current.put("time", System.currentTimeMillis());
            next.put(current);
            for (int i = 0; i < arr.length() && next.length() < 100; i++) {
                JSONObject old = arr.optJSONObject(i); if (old == null) continue;
                if (!url.equals(old.optString("url"))) next.put(old);
            }
            writeJsonArray("history", next);
        } catch (Exception ignored) {}
    }

    private JSONArray readJsonArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void writeJsonArray(String key, JSONArray arr) { prefs.edit().putString(key, arr.toString()).apply(); }

    private void showBookmarks() { showSavedList("Yer İmleri", readJsonArray("bookmarks"), true); }
    private void showHistory() { showSavedList("Geçmiş", readJsonArray("history"), false); }

    private void showSavedList(String title, JSONArray arr, boolean bookmarkMode) {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14), dp(12), dp(14), dp(12)); box.setBackground(rounded(bg(), dp(26)));
        TextView head = tv(title, 22); head.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); box.addView(head, new LinearLayout.LayoutParams(-1, dp(54)));
        ScrollView scroll = new ScrollView(this); LinearLayout rows = new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); scroll.addView(rows);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i); if (o == null) continue;
            String t = o.optString("title", o.optString("url", "Sayfa")); String u = o.optString("url", "");
            TextView row = tv(t + "\n" + u, 13); row.setBackground(rounded(card(), dp(16))); row.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(66)); rp.setMargins(0, dp(3), 0, dp(3)); rows.addView(row, rp);
            final String url = u;
            row.setOnClickListener(v -> { openUrl(url); d.dismiss(); });
        }
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout actions = new LinearLayout(this);
        Button clear = actionButton(bookmarkMode ? "Yer imlerini temizle" : "Geçmişi temizle");
        Button close = actionButton("Kapat"); actions.addView(clear, new LinearLayout.LayoutParams(0, dp(52), 1f)); actions.addView(close, new LinearLayout.LayoutParams(0, dp(52), 1f));
        box.addView(actions);
        clear.setOnClickListener(v -> { writeJsonArray(bookmarkMode ? "bookmarks" : "history", new JSONArray()); d.dismiss(); });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); d.show();
        Window w = d.getWindow(); if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(24), dp(560)), Math.min(getResources().getDisplayMetrics().heightPixels - dp(80), dp(760))); }
    }

    private void findInPage() {
        if (active() == null) return;
        final EditText e = new EditText(this); e.setSingleLine(true); e.setHint("Sayfada bul");
        new AlertDialog.Builder(this).setTitle("Sayfada bul").setView(e).setPositiveButton("Bul", (dialog, which) -> active().findAllAsync(e.getText().toString())).setNegativeButton("Kapat", null).show();
    }

    private void share() {
        WebView w = active(); if (w == null || w.getUrl() == null) return;
        Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, w.getUrl());
        startActivity(Intent.createChooser(i, "Paylaş"));
    }

    private void settings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(4), dp(18), 0);
        TextView section = tv("AI", 16); section.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); box.addView(section);

        Spinner provider = new Spinner(this);
        String[] providers = {"Gemini", "Groq"};
        provider.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, providers));
        provider.setSelection("Groq".equals(prefs.getString("provider", "Gemini")) ? 1 : 0);
        box.addView(label("Sağlayıcı")); box.addView(provider);

        final Spinner modelSpinner = new Spinner(this);
        box.addView(label("Model")); box.addView(modelSpinner);
        final EditText apiKey = new EditText(this); apiKey.setSingleLine(true); apiKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); apiKey.setHint("API anahtarı"); apiKey.setText(prefs.getString("apiKey", ""));
        box.addView(label("API anahtarı")); box.addView(apiKey);
        final EditText customModel = new EditText(this); customModel.setSingleLine(true); customModel.setHint("Özel model ID (isteğe bağlı)"); customModel.setText(prefs.getString("customModel", ""));
        box.addView(label("Özel model")); box.addView(customModel);

        Runnable refreshModels = () -> {
            String[] models;
            if (provider.getSelectedItemPosition() == 1) {
                models = new String[]{"openai/gpt-oss-120b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant"};
            } else {
                models = new String[]{"gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash", "gemini-2.5-flash", "gemini-2.5-pro"};
            }
            modelSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, models));
            String current = prefs.getString("model", models[0]);
            int found = 0; for (int i = 0; i < models.length; i++) if (models[i].equals(current)) found = i;
            modelSpinner.setSelection(found);
        };
        provider.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { refreshModels.run(); }
        });
        refreshModels.run();

        TextView browserSection = tv("Tarayıcı", 16); browserSection.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); box.addView(browserSection, spacerLp());
        Spinner themeSpinner = new Spinner(this);
        themeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Sistem varsayılanı", "Koyu", "Açık"}));
        int themePos = "light".equals(theme) ? 2 : "dark".equals(theme) ? 1 : 0; themeSpinner.setSelection(themePos);
        box.addView(label("Tema")); box.addView(themeSpinner);

        Spinner searchEngine = new Spinner(this);
        String[] engines = {"Google", "Bing", "DuckDuckGo"}; searchEngine.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, engines));
        String engine = prefs.getString("searchEngine", "Google");
        searchEngine.setSelection("Bing".equals(engine) ? 1 : "DuckDuckGo".equals(engine) ? 2 : 0);
        box.addView(label("Arama motoru")); box.addView(searchEngine);

        TextView privacy = tv("API anahtarı yalnızca bu cihazın uygulama verilerinde saklanır. Gizli sekmeler geçmişe ve açık sekme yedeklerine eklenmez.", 12); privacy.setTextColor(subColor()); privacy.setPadding(dp(2), dp(12), dp(2), dp(6)); box.addView(privacy);

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Ayarlar").setView(box)
                .setPositiveButton("Kaydet", null).setNegativeButton("İptal", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String selected = ((String) provider.getSelectedItem());
            String manual = customModel.getText().toString().trim();
            String selectedModel = manual.isEmpty() ? String.valueOf(modelSpinner.getSelectedItem()) : manual;
            int pos = themeSpinner.getSelectedItemPosition();
            theme = pos == 1 ? "dark" : pos == 2 ? "light" : "system";
            prefs.edit().putString("provider", selected).putString("model", selectedModel).putString("customModel", manual)
                    .putString("apiKey", apiKey.getText().toString().trim()).putString("theme", theme)
                    .putString("searchEngine", String.valueOf(searchEngine.getSelectedItem())).apply();
            applyTheme(); updateChrome(); showHome(); dialog.dismiss();
        }));
        dialog.show();
    }

    private TextView label(String s) { TextView t = tv(s, 12); t.setTextColor(subColor()); t.setPadding(dp(2), dp(8), dp(2), dp(2)); return t; }
    private LinearLayout.LayoutParams spacerLp() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(38)); return p; }

    private void showAiPanel() {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16), dp(10), dp(16), dp(12)); box.setBackground(rounded(bg(), dp(26)));
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("🤖  NetAI", 21); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); head.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView model = tv(prefs.getString("provider", "Gemini") + " • " + prefs.getString("model", "gemini-3.8-flash"), 11); model.setTextColor(subColor()); head.addView(model, new LinearLayout.LayoutParams(dp(180), dp(52)));
        Button close = actionButton("×"); head.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48))); box.addView(head);

        ScrollView scroll = new ScrollView(this);
        TextView chat = tv("Hazırım.\n\nÖrnekler:\n• “Bana Hepsiburada'yı aç.”\n• “YouTube'u aç.”\n• “Google'da Android WebView ara.”\n• “Bu sayfayı özetle.”", 14);
        chat.setPadding(dp(8), dp(6), dp(8), dp(10)); scroll.addView(chat); box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout inputRow = new LinearLayout(this); inputRow.setGravity(Gravity.CENTER_VERTICAL);
        final EditText input = new EditText(this); input.setHint("AI'ya yaz..."); input.setTextColor(textColor()); input.setHintTextColor(subColor()); input.setMaxLines(4); input.setPadding(dp(14), dp(6), dp(14), dp(6)); input.setBackground(rounded(panel(), dp(20)));
        Button send = actionButton("Gönder"); send.setTextSize(13); inputRow.addView(input, new LinearLayout.LayoutParams(0, dp(58), 1f)); inputRow.addView(send, new LinearLayout.LayoutParams(dp(86), dp(58))); box.addView(inputRow);
        send.setOnClickListener(v -> { String q = input.getText().toString().trim(); if (q.isEmpty()) return; chat.append("\n\nSen: " + q + "\nNetAI: düşünüyor…"); input.setText(""); handleAi(q, chat); });
        input.setOnEditorActionListener((v, id, event) -> { send.performClick(); return true; });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); d.show(); Window w = d.getWindow(); if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(24), dp(600)), Math.min(getResources().getDisplayMetrics().heightPixels - dp(80), dp(820))); }
        input.requestFocus();
    }

    private void handleAi(String query, TextView chat) {
        String q = query.trim();
        String low = q.toLowerCase(Locale.ROOT);
        String direct = knownSite(low);
        if (direct != null) { openUrl(direct); chat.append("\nNetAI: Doğrudan açıyorum → " + direct); return; }

        String searchTerm = extractGoogleSearch(low, q);
        if (searchTerm != null && !searchTerm.isEmpty()) {
            openUrl(searchUrl(searchTerm)); chat.append("\nNetAI: Google aramasını açıyorum → " + searchTerm); return;
        }

        WebView page = active();
        if (containsAny(low, "bu sayfayı özetle", "bu sayfayi ozetle", "sayfayı özetle", "sayfayi ozetle", "bu sayfa ne anlatıyor", "bu sayfa ne anlatiyor")) {
            if (page == null || page.getUrl() == null || page.getUrl().startsWith("about:")) { chat.append("\nNetAI: Özetleyebilmem için açık bir web sayfası gerekli."); return; }
            chat.append("\nNetAI: Sayfa metnini okuyorum…");
            page.evaluateJavascript("(function(){try{return document.body?document.body.innerText.slice(0,30000):''}catch(e){return ''}})();", raw -> {
                String text = decodeJsString(raw);
                askProvider(q + "\n\nAşağıdaki sayfa içeriğini Türkçe özetle. Ana noktaları ve önemli bilgileri koru:\n" + text, chat);
            });
            return;
        }
        askProvider(q, chat);
    }

    private void askProvider(String userQuery, TextView chat) {
        String key = prefs.getString("apiKey", "");
        if (key.isEmpty()) { chat.append("\nNetAI: Önce Ayarlar > AI bölümünden Gemini veya Groq API anahtarını gir."); return; }
        String provider = prefs.getString("provider", "Gemini");
        String model = prefs.getString("model", "Gemini".equals(provider) ? "gemini-3.8-flash" : "openai/gpt-oss-120b");
        String currentUrl = active() == null ? "" : String.valueOf(active().getUrl());
        executor.execute(() -> {
            try {
                String system = "Sen NetAI Browser'ın Türkçe AI yardımcısısın. Kullanıcı bir siteyi açmanı isterse URL biliyorsan ilk satırda OPEN_URL:https://... kullan. Kullanıcı web araması isterse SEARCH_URL:https://www.google.com/search?q=... kullan. URL sadece http veya https olsun. Kullanıcının isteğini kısa ve net yerine getir. Mevcut sayfa URL'si: " + currentUrl;
                String answer = "Gemini".equalsIgnoreCase(provider) ? gemini(key, model, system, userQuery) : groq(key, model, system, userQuery);
                runOnUiThread(() -> handleAiResponse(answer, chat));
            } catch (Exception e) {
                runOnUiThread(() -> chat.append("\nNetAI: API hatası — " + friendlyError(e.getMessage())));
            }
        });
    }

    private void handleAiResponse(String answer, TextView chat) {
        if (answer == null) return;
        String trimmed = answer.trim();
        if (trimmed.startsWith("OPEN_URL:")) {
            String u = firstToken(trimmed.substring("OPEN_URL:".length()).trim());
            if (isHttpUrl(u)) { openUrl(u); chat.append("\nNetAI: Siteyi doğrudan açıyorum → " + u); return; }
        }
        if (trimmed.startsWith("SEARCH_URL:")) {
            String u = firstToken(trimmed.substring("SEARCH_URL:".length()).trim());
            if (isHttpUrl(u)) { openUrl(u); chat.append("\nNetAI: Aramayı açıyorum."); return; }
        }
        chat.append("\nNetAI: " + trimmed);
    }

    private String knownSite(String q) {
        if (!(containsAny(q, "aç", "ac", "açar", "açsana", "git", "göster", "goster", "siteyi", "sitesini"))) return null;
        String[][] aliases = {
                {"hepsiburada", "https://www.hepsiburada.com"}, {"hepsiburada'yı", "https://www.hepsiburada.com"},
                {"trendyol", "https://www.trendyol.com"}, {"sahibinden", "https://www.sahibinden.com"},
                {"n11", "https://www.n11.com"}, {"amazon", "https://www.amazon.com"},
                {"youtube", "https://www.youtube.com"}, {"google", "https://www.google.com"},
                {"instagram", "https://www.instagram.com"}, {"facebook", "https://www.facebook.com"},
                {"twitter", "https://x.com"}, {"x'i", "https://x.com"}, {"tiktok", "https://www.tiktok.com"},
                {"wikipedia", "https://tr.wikipedia.org"}, {"github", "https://github.com"},
                {"reddit", "https://www.reddit.com"}, {"netflix", "https://www.netflix.com"},
                {"linkedin", "https://www.linkedin.com"}, {"microsoft", "https://www.microsoft.com"},
                {"apple", "https://www.apple.com"}, {"discord", "https://discord.com"}
        };
        for (String[] a : aliases) if (q.contains(a[0])) return a[1];
        return null;
    }

    private String extractGoogleSearch(String low, String original) {
        if (!(low.contains("google'da ara") || low.contains("google da ara") || low.startsWith("ara ") || low.startsWith("arama yap "))) return null;
        String s = original.replaceFirst("(?i)^.*?google[’']?da(.*?)ara\\s*", "").trim();
        if (s.isEmpty()) s = original.replaceFirst("(?i)^ara\\s*", "").trim();
        if (s.isEmpty()) s = original.replaceFirst("(?i)^arama yap\\s*", "").trim();
        return s;
    }

    private String searchUrl(String term) {
        String engine = prefs.getString("searchEngine", "Google");
        if ("Bing".equals(engine)) return "https://www.bing.com/search?q=" + Uri.encode(term);
        if ("DuckDuckGo".equals(engine)) return "https://duckduckgo.com/?q=" + Uri.encode(term);
        return "https://www.google.com/search?q=" + Uri.encode(term);
    }

    private boolean containsAny(String s, String... items) { for (String x : items) if (s.contains(x)) return true; return false; }
    private boolean isHttpUrl(String u) { return u != null && (u.startsWith("https://") || u.startsWith("http://")); }
    private String firstToken(String s) { String[] p = s.split("\\s+", 2); return p.length == 0 ? "" : p[0].replace("\"", "").replace("'", ""); }
    private String decodeJsString(String raw) { if (raw == null || "null".equals(raw)) return ""; String s = raw; if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length() - 1); return s.replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t").replace("\\\"", "\"").replace("\\\\", "\\"); }

    private String gemini(String key, String model, String system, String user) throws Exception {
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + URLEncoder.encode(model, StandardCharsets.UTF_8.name()) + ":generateContent");
        JSONObject body = new JSONObject();
        JSONObject sys = new JSONObject(); sys.put("parts", new JSONArray().put(new JSONObject().put("text", system))); body.put("systemInstruction", sys);
        JSONArray contents = new JSONArray();
        JSONObject content = new JSONObject(); content.put("role", "user"); content.put("parts", new JSONArray().put(new JSONObject().put("text", user))); contents.put(content);
        body.put("contents", contents);
        return parseGemini(post(url, body.toString(), "application/json", "x-goog-api-key", key));
    }

    private String parseGemini(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!o.has("candidates")) throw new Exception(o.optString("error", "Gemini yanıtı alınamadı"));
        JSONArray c = o.getJSONArray("candidates");
        if (c.length() == 0) throw new Exception("Gemini boş yanıt verdi");
        return c.getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "").trim();
    }

    private String groq(String key, String model, String system, String user) throws Exception {
        URL url = new URL("https://api.groq.com/openai/v1/chat/completions");
        JSONObject body = new JSONObject(); body.put("model", model); body.put("temperature", 0.2); body.put("max_completion_tokens", 2048);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", system));
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        body.put("messages", msgs);
        JSONObject root = new JSONObject(post(url, body.toString(), "application/json", "Authorization", "Bearer " + key));
        return root.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim();
    }

    private String post(URL url, String body, String contentType, String... headers) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(45000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", contentType); c.setRequestProperty("Accept", "application/json");
        for (int i = 0; i + 1 < headers.length; i += 2) c.setRequestProperty(headers[i], headers[i + 1]);
        try (OutputStream out = c.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode(); InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (stream == null) throw new Exception("Sunucudan yanıt alınamadı (HTTP " + code + ")");
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) result.append(line);
        }
        if (code >= 400) throw new Exception("HTTP " + code + ": " + result);
        return result.toString();
    }

    private String friendlyError(String message) {
        if (message == null) return "Bilinmeyen hata";
        if (message.contains("401")) return "API anahtarı geçersiz veya yetkisiz.";
        if (message.contains("403")) return "API erişimi reddedildi.";
        if (message.contains("404")) return "Model bulunamadı. Ayarlardan başka bir model seç.";
        if (message.contains("429")) return "İstek limiti aşıldı. Biraz sonra tekrar dene.";
        return message.length() > 220 ? message.substring(0, 220) : message;
    }

    private void addFabToFrame() {
        if (aiFab.getParent() != null) ((ViewGroup) aiFab.getParent()).removeView(aiFab);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(62), dp(62));
        float x = prefs.getFloat("fab_x", -1f), y = prefs.getFloat("fab_y", -1f);
        if (x >= 0 && y >= 0) { lp.leftMargin = (int) x; lp.topMargin = (int) y; }
        else { lp.gravity = Gravity.RIGHT | Gravity.BOTTOM; lp.setMargins(0, 0, dp(18), dp(18)); }
        browserFrame.addView(aiFab, lp);
    }

    private void makeDraggable(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            float dX, dY; long down;
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = view.getX() - e.getRawX(); dY = view.getY() - e.getRawY(); down = System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE:
                        view.setX(clamp(e.getRawX() + dX, 0, browserFrame.getWidth() - view.getWidth()));
                        view.setY(clamp(e.getRawY() + dY, 0, browserFrame.getHeight() - view.getHeight())); return true;
                    case MotionEvent.ACTION_UP:
                        if (System.currentTimeMillis() - down < 180) view.performClick();
                        else prefs.edit().putFloat("fab_x", view.getX()).putFloat("fab_y", view.getY()).apply();
                        return true;
                    default: return true;
                }
            }
        });
    }

    private float clamp(float value, float min, float max) { return Math.max(min, Math.max(max, value)); }

    private void download(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setMimeType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setTitle(WebViewDatabaseName(url));
            req.setDescription("NetAI Browser");
            req.addRequestHeader("User-Agent", userAgent == null ? "" : userAgent);
            String cookie = CookieManager.getInstance().getCookie(url); if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(req); toast("İndirme başlatıldı");
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { toast("İndirme başlatılamadı"); }
        }
    }

    private String WebViewDatabaseName(String url) { return URLUtil.guessFileName(url, null, null); }

    private void openUrl(String url) {
        if (!isHttpUrl(url)) return;
        showBrowser();
        if (active() != null) active().loadUrl(url);
    }

    private void navigate(String raw) {
        if (TextUtils.isEmpty(raw)) return;
        String s = raw.trim(); if (s.isEmpty()) return;
        showBrowser();
        if (isHttpUrl(s)) { active().loadUrl(s); return; }
        if (s.matches("(?i)^(localhost|[a-z0-9][a-z0-9.-]*\\.[a-z]{2,})(/.*)?(:[0-9]+)?$")) { active().loadUrl("https://" + s); return; }
        active().loadUrl(searchUrl(s));
    }

    private void openKeyboard() {
        address.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(address, InputMethodManager.SHOW_IMPLICIT);
        }, 200);
    }

    private int indexOf(WebView view) { for (int i = 0; i < tabs.size(); i++) if (tabs.get(i).web == view) return i; return -1; }
    private Tab findTab(WebView view) { for (Tab t : tabs) if (t.web == view) return t; return null; }

    private void updateChrome() {
        if (root == null) return;
        root.setBackgroundColor(bg()); toolbar.setBackgroundColor(bg()); bottomBar.setBackgroundColor(panel());
        if (address != null) { address.setTextColor(textColor()); address.setHintTextColor(subColor()); address.setBackground(rounded(panel(), dp(28))); }
        if (backBtn != null) { backBtn.setTextColor(textColor()); forwardBtn.setTextColor(textColor()); reloadBtn.setTextColor(textColor()); }
        if (tabCount != null) tabCount.setText(String.valueOf(tabs.size()));
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override protected void onResume() { super.onResume(); updateChrome(); }
    @Override protected void onPause() { saveOpenTabs(); super.onPause(); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS && pendingGeoCallback != null && pendingGeoOrigin != null) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            GeolocationPermissions.Callback cb = pendingGeoCallback;
            String origin = pendingGeoOrigin;
            pendingGeoCallback = null; pendingGeoOrigin = null;
            if (granted) {
                new AlertDialog.Builder(this).setTitle("Konum izni").setMessage(origin + " konumunuza erişmek istiyor.")
                        .setPositiveButton("İzin ver", (d, w) -> cb.invoke(origin, true, false))
                        .setNegativeButton("Reddet", (d, w) -> cb.invoke(origin, false, false)).show();
            } else cb.invoke(origin, false, false);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount(); result = new Uri[n];
                    for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (active() != null && active().canGoBack()) active().goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        saveOpenTabs();
        executor.shutdownNow();
        for (Tab t : tabs) { try { t.web.stopLoading(); t.web.destroy(); } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
